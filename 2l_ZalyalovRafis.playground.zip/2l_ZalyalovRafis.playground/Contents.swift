import UIKit

// Написать функцию, которая определяет, четное число или нет.

var numberArray = (1...50)

for number in numberArray {
    if number % 2 == 0 {
        print("Число ", number, "четное")
    } else {
        print("Число ", number, "не четное")
    }
}

// Написать функцию, которая определяет, делится ли число без остатка на 3
for number1 in numberArray {
    if number1 % 3 == 0 {
        print("Число ", number1, "делится на 3")
    } else {
        print("Число ", number1, "не делится на 3")
    }
}

// Создать возрастающий массив из 100 чисел.

var houndredNumbers = Array(1...100)
for i in houndredNumbers {
    print(i)
}

//Удалить из этого массива все четные числа и все числа, которые не делятся на 3

var filterNum = houndredNumbers.filter({$0 % 2 != 0 && $0 % 3 == 0 })
print(filterNum)

